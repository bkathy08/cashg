<p class="loading d-none text-center"><i class="fa fa-spinner fa-spin"></i></p>

@push('style')
    <style>
        .loading {
            min-height: 150px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
@endpush
